#pragma once

static const int InitialWidth = 1920;
static const int InitialHeight = 1080;
static float Scale = 1.0f;